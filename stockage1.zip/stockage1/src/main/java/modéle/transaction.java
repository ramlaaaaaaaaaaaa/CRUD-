/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modéle;

import java.sql.Date;

/**
 *
 * @author doc
 */
public class transaction {
     private int id_transaction;
    private int id_stock ;
    private Date date_transaction ;


public transaction () {
    }

    public transaction(int id_transaction, int id_stock, Date date_transaction) {
        this.id_transaction = id_transaction;
        this.id_stock = id_stock;
        this.date_transaction = date_transaction;
    }

    public int getId_stock() {
        return id_stock;
    }

    public void setId_stock(int id_stock) {
        this.id_stock = id_stock;
    }

    public Date getDate_transaction() {
        return date_transaction;
    }

    public void setDate_transaction(Date date_transaction) {
        this.date_transaction = date_transaction;
    }

   

    public int getId_transaction() {
        return id_transaction;
    }

    public void setid_transaction(int id_transaction) {
        this.id_transaction = id_transaction;
    }

   

    @Override
    public String toString() {
        return "transaction{" + "id_transaction=" + id_transaction + ", id_utilisateur=" + id_stock + ", date_transaction=" + date_transaction + '}';
    }


    
    
    
}
