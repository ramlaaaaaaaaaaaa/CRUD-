/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modéle;

/**
 *
 * @author doc
 */
public class stock {
     private int id_stock ;
   private String date_echange ;
   private int qte;

  
public stock (){
    }

    public stock (int id_stock , int qte , String  date_echange ) {
        this.id_stock = id_stock;
        this.date_echange = date_echange;
        this.qte = qte;
    }

    public int getId_stock() {
        return id_stock;
    }

    public void setId_stock(int id_stock) {
        this.id_stock = id_stock;
    }

    public String getDate_echange() {
        return date_echange;
    }

    public void setDate_echange(String date_echange) {
        this.date_echange = date_echange;
    }

    public int getQte() {
        return qte;
    }

    public void setQte(int qte) {
        this.qte = qte;
    }

    

    @Override
    public String toString() {
        return "stock{" + "id_stock=" + id_stock + ", date_stock=" + date_echange + ", qte=" + qte + '}';
    }


    
    
}
