/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

import java.util.List;
import modéle.stock;
import modéle.transaction;

/**
 *
 * @author doc
 */
public interface transactionInterface {
    //add
    public void addtransaction (transaction  t);
    
    //list : select
    public List<transaction > fetchtransactions();
    
    //affectation
    public void affectertransaction (transaction t, stock s);
    public void deletetransaction (int id_transaction);
    public void updatetransaction (int id_transaction ,int id_stock ,String date_transaction);
    public void recherchertransaction (int id_transaction);
    public void affichertransaction (transaction  t);
    
    
}
