/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

import java.util.List;
import modéle.stock;
import modéle.transaction;

/**
 *
 * @author doc
 */
public interface stockInterface {
    

/**
 *
 * @author adelb
 */

     //add
    public void addstock (stock s);
    
    //list : select
    public List<stock> fetchstocks();
    
    //affectation
    public void affecterstock(stock s, transaction t);
    public void deletestock(int id_stock);
    public void updatestock(int id_stock,int qte, String date_echange);
    public void rechercherstock(int id_stock);
    public void afficherstock(stock s);
    
    
}
