/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.stockage1;
import services.stockService;
import interfaces.stockInterface;
import modéle.stock;



/**
 *
 * @author doc
 */
public class Stockage1 {

    public static void main(String[] args) {
       stockInterface ps= new stockService();
        stock s1 = new stock ();
        //stock s3 = new stock ();
       // stock s4 = new stock ();
        
        s1.setQte(5);
        s1.setDate_echange("2021-12-5");
        ps.addstock(s1);
        
        System.out.println(ps.fetchstocks());
    }
}
