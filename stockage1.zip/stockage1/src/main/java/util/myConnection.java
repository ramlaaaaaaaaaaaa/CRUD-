/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author doc
 */

public class myConnection {
    
    //DB PARAM
    static final String URL ="jdbc:mysql://localhost:3306/stockage";
    static final String USER ="root";
    static final String PASSWORD ="";
    
    //var
    private Connection cnx;
    //1
    static myConnection instance;
    
    //const
    //2
    private myConnection(){
        try {
            cnx = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException ex) {
        }
    }
    
    
    public Connection getCnx() {
        return cnx;
    }

    //3
    public static myConnection getInstance() {
        if(instance == null)
            instance = new myConnection();
        
        return instance;
    }
    
    
    
}