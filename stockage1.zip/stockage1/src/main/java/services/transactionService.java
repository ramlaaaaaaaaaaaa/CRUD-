/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package services;


import interfaces.transactionInterface;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import modéle.stock;
import modéle.transaction;
import util.myConnection;

/**
 *
 * @author doc
 */
public class transactionService implements transactionInterface{
    //var
    Connection cnx = myConnection.getInstance().getCnx();

    @Override
    public void addtransaction(transaction t) {
        try {
            
            String req = "INSERT INTO `transaction`(`date_transaction`, `id_utilisateur`) VALUES ("+t.getDate_transaction()+",'"+t.getId_stock()+"')";
            Statement st = cnx.createStatement();
            st.executeUpdate(req);
            System.out.println("transaction Added successfully!");
        } catch (SQLException ex) {
        }
    }
    
    
    @Override
    public List<transaction> fetchtransactions() {
        List<transaction> transactions = new ArrayList<>();
        try {
            
            String req = "SELECT * FROM <transaction>";
            Statement st = cnx.createStatement();
            ResultSet rs = st.executeQuery(req);
            while (rs.next()) {                
               transaction t = new transaction();
                t.setid_transaction(rs.getInt(2));
                t.setId_stock(rs.getInt(1));
                t.setDate_transaction(rs.getDate("date_transaction"));
                
                
                    transactions.add(t);
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return transactions;
    }
    
    
    
    
    @Override
    public void deletetransaction(int id_transaction){
        
        try {
            String req = "DELETE FROM `transaction` WHERE id_transaction = "+id_transaction;
            Statement st = cnx.createStatement();
            st.executeUpdate(req);
            System.out.println("transaction deleted successfully!");
        } catch (SQLException ex) {
        }
        
        
    }
    
    @Override
    public void updatetransaction(int id_transaction ,int id_stock ,String date_transaction){
        
        try {
            String req = "UPDATE `transaction` SET `date_transaction`='?',`id_stock`='?' WHERE id_transaction ="+id_transaction;
            Statement st = cnx.createStatement();
            st.executeUpdate(req);
            System.out.println("stock updated successfully!");
        } catch (SQLException ex) {
        }
        
        
    }
    
    @Override
    public void recherchertransaction(int id_transaction){
        
        try {
            String req = "SELECT * FROM `transaction` WHERE id_transaction = "+id_transaction;
            Statement st = cnx.createStatement();
            st.executeUpdate(req);
            System.out.println("transaction found successfully!");
        } catch (SQLException ex) {
        }
        
        
    }
    
    @Override
    public void affichertransaction(transaction t){
        
        try {
            String req = "SELECT `id_transaction`, `id_utilisateur`, `date_transaction` FROM `transaction` WHERE id_transaction = "+t.getId_transaction();
            Statement st = cnx.createStatement();
            st.executeUpdate(req);
            System.out.println("transaction found successfully!");
        } catch (SQLException ex) {
        }
        
        
    }

    @Override
    public void affectertransaction(transaction t, stock s) {
       try {
            String req ="UPDATE `transaction` SET `stock`= ? WHERE id_transaction = ?";
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setInt(1, t.getId_transaction());
            ps.setInt(2, s.getId_stock());
            ps.executeUpdate();
            System.out.println("Player updated successfully!");
        } catch (SQLException ex) {
        }
        }
    
}
