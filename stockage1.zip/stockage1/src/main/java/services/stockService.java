/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package services;

import interfaces.stockInterface;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import modéle.stock;
import modéle.transaction;
import util.myConnection;


/**
 *
 * @author doc
 */
public class stockService implements stockInterface{
     //var
    Connection cnx = myConnection.getInstance().getCnx();

    
    @Override
    public void afficherstock(stock s){
        
        try {
            String req = "SELECT `id_stock`, `date_echange`, `qte` FROM `stock` WHERE id_stock = "+s.getId_stock();
            Statement st = cnx.createStatement();
            st.executeUpdate(req);
            System.out.println("stock found successfully!");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        }

    @Override
    public void addstock(stock s) {
       try {
            
            String req = "INSERT INTO `stock`(`date_echange`, `qte`) VALUES ('"+s.getDate_echange()+"',"+s.getQte()+")";
            Statement st = cnx.createStatement();
            st.executeUpdate(req);
            System.out.println("stock Added successfully!");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public List<stock> fetchstocks() {
          List<stock> stocks = new ArrayList<>();
        try {
            
            String req = "SELECT * FROM stock";
            Statement st = cnx.createStatement();
            ResultSet rs = st.executeQuery(req);
            while (rs.next()) {                
                stock s = new stock();
                s.setId_stock(rs.getInt(1));
                s.setQte(rs.getInt(2));
                s.setDate_echange(rs.getString("date_echange"));
                
                
                stocks.add(s);
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return stocks;
    }

    
    @Override
  
    public void deletestock(int id_stock) {
       try {
            String req = "DELETE FROM `stock` WHERE id_stock = "+id_stock;
            Statement st = cnx.createStatement();
            st.executeUpdate(req);
            System.out.println("produit deleted successfully!");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

     @Override
    public void updatestock(int id_stock,int qte, String date_echange) {
          try {
            String req = "UPDATE `stock` SET `date_echange`='?',`qte`='?' WHERE id_stock ="+id_stock;
            Statement st = cnx.createStatement();
            st.executeUpdate(req);
            System.out.println("stock updated successfully!");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

        @Override
    public void rechercherstock(int id_stock) {
        
        try {
            String req = "SELECT * FROM `stock` WHERE id_stock = "+id_stock;
            Statement st = cnx.createStatement();
            ResultSet rst=st.executeQuery(req);
            rst.last();
            int nbrow = rst.getRow();
            if (nbrow!=0){
                    System.out.println("product found successfully!");
            }else{
                System.out.println("product not found !");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void affecterstock(stock s, transaction t) {
        try {
            String req ="UPDATE `stock` SET `transaction`= ? WHERE id_stock = ?";
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setInt(1, t.getId_transaction());
            ps.setInt(2, s.getId_stock());
            ps.executeUpdate();
            System.out.println("Stock updated successfully!");
        } catch (SQLException ex) {
        }
    }
    
}
